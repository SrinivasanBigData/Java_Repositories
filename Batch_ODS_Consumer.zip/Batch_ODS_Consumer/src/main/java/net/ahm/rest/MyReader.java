package net.ahm.rest;

import org.springframework.batch.item.database.JdbcPagingItemReader;
//https://stackoverflow.com/questions/6078009/how-to-get-access-to-job-parameters-from-itemreader-in-spring-batch
//https://blog.codecentric.de/en/2013/06/spring-batch-2-2-javaconfig-part-2-jobparameters-executioncontext-and-stepscope/
//http://malsolo.com/blog4java/?p=260
//http://rgordon.co.uk/blog/2012/02/02/passing-a-parameter-from-oddjob-to-spring-batch/
public class MyReader extends JdbcPagingItemReader<String>{

	
}
