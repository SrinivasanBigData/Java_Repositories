package net.ahm.rest.config;

public class ConsumerConfig {

}
