'''
Created on 20-May-2017

@author: srinivasan
'''

class Error(Exception):
    """
    Custom Error For Rally Bot APP
    """
    def __init__(self):
        pass

class RallyConnectionError(Error):
    
    def __init__(self, **msg):
        self._msg = "failed to connect  Rally server({server})  with user {user}".format(**msg)
        
    def __str__(self, *args, **kwargs):
        return self._msg
