'''
Created on 20-May-2017

@author: srinivasan
'''
import json
with open('/home/srinivasan/eclipse/workspace_python/RallyBot/SampleDefect', 'r') as json_data:
    json.load(json_data)