'''
Created on 20-May-2017

@author: srinivasan
'''
import sys
class A(object):
    
    def __init__(self, **kwargs):
        from pyral.restapi import Rally
        rally = Rally(**kwargs)
        rally.enableLogging('rally.simple-use.log')
        target_story = rally.get('UserStory', query='FormattedID="US86929"')
        print target_story
        
a = {'server':'rally1.rallydev.com',
     'user':'sramalingam@activehealth.net',
     'password':'Eceseenu1989@', 'workspace':'Healthagen', 'project':'PHIT'}
aa = A(**a)