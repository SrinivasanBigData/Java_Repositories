'''
Created on 20-May-2017

@author: srinivasan
'''
from pyral.restapi import Rally
import sys
rally = Rally("rally1.rallydev.com", "sramalingam@activehealth.net", "Eceseenu1989@",
               workspace="Healthagen")
rally.enableLogging('rally.simple-use.log')
response = rally.get('UserStory', fetch=True)
    # a response has status_code, content and data attributes
  
for task in response:
    print task.__dict__

sys.exit(-1)
workspaces = rally.getWorkspaces()
for wksp in workspaces:
    print "%s %s" % (wksp.oid, wksp.Name)
all_users = rally.getAllUsers()
for user in all_users:
    tz = user.UserProfile.TimeZone or 'default'
    role = user.Role or '-No Role-'
    values = (int(user.oid), user.Name, user.UserName, role, tz)
    print("%12.12d %-24.24s %-30.30s %-12.12s" % values)
