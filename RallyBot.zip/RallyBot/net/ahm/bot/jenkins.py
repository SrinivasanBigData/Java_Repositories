'''
Created on 20-May-2017

@author: srinivasan
'''
from jenkinsapi.jenkins import Jenkins

jenkins = Jenkins('https://ci.jenkins-ci.org/', ssl_verify=True)
jobName = jenkins.keys()
print jobName
