'''
Created on 20-May-2017

@author: srinivasan
'''
import datetime
from enum import Enum
from net.ahm.exception import RallyConnectionError

class __ScheduleStates(Enum):
    
    DEFINED = 'Defined'
    IN_PROGRESS = 'In-Progress'
    COMPLETED = 'Completed'
    ACCEPTED = 'Accepted'

class __DefectStates(Enum):
    
    OPEN = 'open'
    CLOSE = 'close'

class RallyOperation(object):
    
    def __init__(self, **kwargs):
        try:
            """
            Connect to Rally Server
            """
            from pyral.restapi import Rally
            self._rally = Rally(**kwargs)
        except RallyConnectionError as (error):
            # log message
            pass
        else:
            # log message
            self._rally.enableLogging('rally.simple-use.log')
    
    """
    Get Current Iteration Information
    """
    @property
    def current_iteration(self):
        today = datetime.datetime.now().strftime('%Y-%m-%d')
        return self.getIteration(today, today)
    
    """
    Get iteration Information Based on start Date and End Date
    """
    def getIteration(self, StartDate=None, EndDate=None):
        query = ['StartDate <= "{}"'.format(StartDate.strftime('%Y-%m-%d')),
                 'EndDate >= "{}"'.format(EndDate.strftime('%Y-%m-%d'))]
        iterations = self._rally.get('Iteration', query=query)
        return next(iterations)

    """
    Get all  User Stories Based on  Iteration
    """
    def getStories(self, iteration=None):
        return self.__gets('Story', iteration)
    
    """
     Get all  Defects Based on  Iteration
    """
    def getDefects(self, iteration=None):
        return self.__gets('Defect', iteration)
    
    """
     Get all  Tasks Based on  Iteration
    """
    def getTasks(self, iteration=None):
        return self.__gets('Task', iteration)
    
    """
    Get Information
    """
    def __gets(self, entityName=None, iteration=None):
        query = []
        if iteration is not None:
            query = ['Iteration.oid = "{}"'.format(iteration.oid)]
        return self._rally.get(entityName, fetch=True, query=query)

    """
    Get Story Information Based on formatted ID
    """
    def getStory(self, formatted_id):
        return self.__get('UserStory', formatted_id)
    
    """
    Get Defect Information Based on formatted ID
    """
    def getDefect(self, formatted_id):
        return self.__get('Defect', formatted_id)
    
    
    """
    Get Story Information Based on formatted ID
    """
    def getTask(self, formatted_id):
        return self.__get('Task', formatted_id)
    
    """
    Get Known Entity Information
    """
    def getKnownInfo(self, entityName=None, formatted_id=None):
        return self.__get(entityName, formatted_id)
    
    
    """
    Get Information
    """
    def __get(self, entityName=None, formatted_id=None):
        query = ['FormattedID = "{}"'.format(formatted_id)]
        result = self._rally.get(entityName, query=query)
        stories = list(result)
        if not stories:
            raise ValueError('{} does not exist.'.format(entityName))
        else:
            return stories[0]
    
    """
    Updated User Story Information Based on formatted ID
    """
    def updateUserStory(self, **kwargs):
        self.__update('UserStory', kwargs)
    
    """
    Updated Defect Information Based on formatted ID
    """
    def updateDefect(self, **kwargs):
        self.__update('Defect', kwargs)
    
    """
    Updated Task Information Based on formatted ID
    """
    def updateTask(self, **kwargs):
        self.__update('Task', kwargs)
    
    """
    Update Information
    """
    def __update(self, entityName=None, **kwargs):
        try:
            self._rally.update(entityName, kwargs)
        except Exception as(error):
            # log message
            pass
    """
    Update Known status
    """
    def knownUpdate(self, entityName=None, **kwargs):
        self.__update(entityName, kwargs)
        
if __name__ == '__main__':
    a = {'server':'rally1.rallydev.com',
     'user':'sramalingam@activehealth.net',
     'password':'Eceseenu1989@', 'workspace':'Healthagen'}
    r = RallyOperation(**a)
    print r.story("US91491")
    
