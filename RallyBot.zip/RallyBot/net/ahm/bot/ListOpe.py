'''
Created on 20-May-2017

@author: srinivasan
'''
L = [8000, 10, 20, 40]
print filter(lambda x: x > 30, sorted(L, reverse=True))

sample = "US98451 DE4589 lashdlashdl asdlahsldhas"
print [s for s in sample.upper().split() if s[:2] in ["US", "DE"] and s[2:].isdigit()]
