package com.srini.ETL_Operation;

public class CaseTransform implements TransForm {
	private boolean toLower = true;

	public void setCase(String caseType) {
		if (caseType.equalsIgnoreCase("upper")) {
			toLower = false;
		} else {
			toLower = true;
		}
	}

	@Override
	public String transform(String s) {
		if (toLower) {
			return s.toLowerCase();
		}
		return s.toUpperCase();
	}

}
