package com.srini.ETL_Operation;

import java.util.Iterator;
import java.util.LinkedList;

import org.apache.commons.digester3.Digester;
import org.apache.commons.digester3.plugins.PluginCreateRule;

public class CompoundTransform implements TransForm {
	private LinkedList<TransForm> transforms = new LinkedList<TransForm>();

	public void addTransform(TransForm transform) {
		transforms.add(transform);
	}

	@Override
	public String transform(String s) {

		for (Iterator<TransForm> i = transforms.iterator(); i.hasNext();) {
			TransForm t = i.next();
			s = t.transform(s);
		}
		return s;
	}

	public static void addRules(Digester d, String patternPrefix) {
		PluginCreateRule pcr = new PluginCreateRule(TransForm.class);
		d.addRule(patternPrefix + "/subtransform", pcr);
		d.addSetNext(patternPrefix + "/subtransform", "addTransform");
	}
}
