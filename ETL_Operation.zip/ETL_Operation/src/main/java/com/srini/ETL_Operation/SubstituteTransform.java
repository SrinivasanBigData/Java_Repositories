package com.srini.ETL_Operation;

import org.apache.commons.digester3.Digester;

public class SubstituteTransform implements TransForm {
	private String from;
	private String to;

	public void setFrom(String from) {
		this.from = from;
	}

	public void setTo(String to) {
		this.to = to;
	}

	@Override
	public String transform(String s) {
		return s.replaceAll(from, to);
	}

	public static void addRules(Digester d, String patternPrefix) {
		d.addCallMethod(patternPrefix + "/from", "setFrom", 0);
		d.addCallMethod(patternPrefix + "/to", "setTo", 0);
	}

}
