package com.srini.ETL_Operation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.commons.digester3.Digester;
import org.apache.commons.digester3.plugins.PluginCreateRule;
import org.apache.commons.digester3.plugins.PluginRules;


public class App {
	private String source;

	private String dest;

	private TransForm transformer;

	public static void main(String[] args) {
		String configFile = "/home/srinivasan/eclipse/workspace_java/ETL_Operation/compound.xml";
		Digester digester = new Digester();
		PluginRules rc = new PluginRules();
		digester.setRules(rc);
		digester.addObjectCreate("pipeline", App.class);
		digester.addCallMethod("pipeline/source", "setSource", 1);
		digester.addCallParam("pipeline/source", 0, "file");
		PluginCreateRule pcr = new PluginCreateRule(TransForm.class);
		digester.addRule("pipeline/transform", pcr);
		digester.addSetNext("pipeline/transform", "setTransform");
		digester.addCallMethod("pipeline/destination", "setDest", 1);
		digester.addCallParam("pipeline/destination", 0, "file");
		App pipeline = null;
		try {
			pipeline = digester.parse(new File(configFile));
		} catch (Exception e) {
			System.err.println("oops exception occurred during parse.");
			e.printStackTrace();
			System.exit(-1);
		}

		try {
			pipeline.execute();
		} catch (Exception e) {
			System.err
					.println("oops exception occurred during pipeline execution.");
			e.printStackTrace();
			System.exit(-1);
		}
	}

	public void setSource(String source) {
		this.source = source;
	}

	public void setDest(String dest) {
		this.dest = dest;
	}

	public void setTransform(TransForm transformer) {
		this.transformer = transformer;
	}

	private void execute() throws IOException {
		FileReader inRaw = new FileReader(source);
		FileWriter out = new FileWriter(dest);
		BufferedReader in = new BufferedReader(inRaw);
		while (true) {
			String inStr = in.readLine();
			if (inStr == null)
				break;
			String outStr = transformer.transform(inStr);
			out.write(outStr);
			out.write('\n');
		}

		inRaw.close();
		out.close();

		System.out.println("Contents of file " + source
				+ " have been transformed, and" + " written to file " + dest
				+ ".");
	}

}
