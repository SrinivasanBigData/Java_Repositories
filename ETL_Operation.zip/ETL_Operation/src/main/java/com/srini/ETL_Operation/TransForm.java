package com.srini.ETL_Operation;

public interface TransForm {
	public String transform(String s);
}
