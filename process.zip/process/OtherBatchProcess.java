package net.ahm.process;

import org.apache.spark.sql.DataFrame;

public class OtherBatchProcess extends AbstractEligiblityDataProcess<DataFrame> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OtherBatchProcess(DataDigestObjConfig dataDigestObjConfig, SparkDataManager manager) {
		super(dataDigestObjConfig, manager);
	}

	@Override
	public DataFrame execute(DataFrame data) throws EligibilityDataProcessException {
		String newData = "SELECT DISTINCT DIPATIENTID FROM fullMeminsData WHERE MEMTYPE='N'";
		String odsIdtable = generateODSMemberId(data);

		return null;
	}

	@Override
	public void clean() {
		// TODO Auto-generated method stub

	}

	private void newMemberDemog() {
		/**
		 * Add Key Generation logic change fullMeminsData tablename
		 */
		String query = "SELECT * FROM current_demong AS D INNER JOIN"
				+ "    fullMeminsData AS M ON M.DIPATIENTID = D.DIPATIENTID"
				+ "        AND M.RELATIONSHIPTYPCD = D.RELATIONSHIPTYPCD"
				+ "        AND M.AHMSUPPLIERID = D.AHMSUPPLIERID";
	}

	private void getOldDemog() {
		getMember1FData("HistoryMember1F");

		String query = "SELECT * FROM HistoryMember1F AS D INNER JOIN"
				+ "    fullMeminsData AS M ON M.DIPATIENTID = D.DIPATIENTID"
				+ "        AND M.RELATIONSHIPTYPCD = D.RELATIONSHIPTYPCD"
				+ "        AND M.AHMSUPPLIERID = D.AHMSUPPLIERID";

	}

	private void getOldNewDemog() {
		String query = "SELECT * FROM current_demong AS D INNER JOIN"
				+ "    fullMeminsData AS M ON M.DIPATIENTID = D.DIPATIENTID"
				+ "        AND M.RELATIONSHIPTYPCD = D.RELATIONSHIPTYPCD"
				+ "        AND M.AHMSUPPLIERID = D.AHMSUPPLIERID";
	}

}
