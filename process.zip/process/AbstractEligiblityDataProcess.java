package net.ahm.process;

import java.io.Serializable;

import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.types.DataTypes;

public abstract class AbstractEligiblityDataProcess<D> implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DataDigestObjConfig dataDigestObjConfig;
	public SparkDataManager manager;

	public AbstractEligiblityDataProcess(DataDigestObjConfig dataDigestObjConfig, SparkDataManager manager) {
		this.dataDigestObjConfig = dataDigestObjConfig;
		this.manager = manager;
	}

	/**
	 * Execute Data Prepare
	 * 
	 * @param data
	 * @return
	 */
	public abstract D execute(D data) throws EligibilityDataProcessException;

	public String generateODSMemberId(DataFrame dataFrame) {
		long newMeberCount = dataFrame.count();
		if (newMeberCount > 0) {
			DataFrame odsMemberIDDF = dataFrame
					.withColumn("ODSMEMBERID",
							functions.callUDF("generateMemID", dataFrame.col("ODSMEMBERID").cast(DataTypes.LongType)))
					.withColumn("ODSMEMBERPLANID", functions.callUDF("generateMemPlanID",
							dataFrame.col("ODSMEMBERPLANID").cast(DataTypes.LongType)));

		}
		return null;
	}

	public DataFrame getMember1FData(String tableName) {
		return null;
	}

	public abstract void clean();
}
