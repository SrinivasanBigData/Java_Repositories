package net.ahm.process;

public class DataDigestObjConfig {

}
