package net.ahm.process;

import java.util.Optional;
import java.util.function.BooleanSupplier;

import org.apache.spark.sql.DataFrame;

public class EligProcessDecider {

	private static EligProcessDecider decider;

	private EligProcessDecider() {
		// added logger
	}

	/**
	 * 
	 * @param isFirstBatch
	 * @param dataFrame
	 * @param manager
	 * @param dataDigestObjConfig
	 * @return
	 * @throws EligibilityDataProcessException
	 */
	public static DataFrame getMember1CData(BooleanSupplier isFirstBatch, DataFrame dataFrame, SparkDataManager manager,
			DataDigestObjConfig dataDigestObjConfig) throws EligibilityDataProcessException {
		if (!Optional.ofNullable(decider).isPresent()) {
			decider = new EligProcessDecider();
			if (isFirstBatch.getAsBoolean()) {
				return decider.firstBatchProcess(dataFrame, manager, dataDigestObjConfig);
			}
			return decider.otherBatchProcess(dataFrame, manager, dataDigestObjConfig);
		}
		return null;

	}

	/**
	 * 
	 * @param dataFrame
	 * @param manager
	 * @param dataDigestObjConfig
	 * @return
	 * @throws EligibilityDataProcessException
	 */
	private DataFrame firstBatchProcess(DataFrame dataFrame, SparkDataManager manager,
			DataDigestObjConfig dataDigestObjConfig) throws EligibilityDataProcessException {
		FirstBatchDataProcess batchDataProcess = new FirstBatchDataProcess(dataDigestObjConfig, manager);
		return batchDataProcess.execute(dataFrame);
	}

	/**
	 * 
	 * @param dataFrame
	 * @param manager
	 * @param dataDigestObjConfig
	 * @return
	 * @throws EligibilityDataProcessException
	 */
	private DataFrame otherBatchProcess(DataFrame dataFrame, SparkDataManager manager,
			DataDigestObjConfig dataDigestObjConfig) throws EligibilityDataProcessException {
		return null;
	}

}
