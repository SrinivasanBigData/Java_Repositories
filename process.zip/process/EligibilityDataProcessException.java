package net.ahm.process;

public class EligibilityDataProcessException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EligibilityDataProcessException() {
		super();
	}

	public EligibilityDataProcessException(String s) {
		super(s);
	}

	public EligibilityDataProcessException(String s, Throwable throwable) {
		super(s, throwable);
	}

	public EligibilityDataProcessException(Throwable throwable) {
		super(throwable);
	}

}
