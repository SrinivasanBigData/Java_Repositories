package net.ahm.process;

import org.apache.spark.sql.DataFrame;

public class FirstBatchDataProcess extends AbstractEligiblityDataProcess<DataFrame> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FirstBatchDataProcess(DataDigestObjConfig dataDigestObjConfig, SparkDataManager manager) {
		super(dataDigestObjConfig, manager);
	}

	@Override
	public DataFrame execute(DataFrame data) throws EligibilityDataProcessException {

		String newData = "SELECT DISTINCT DIPATIENTID FROM fullMeminsData";
		String odsIdtable = generateODSMemberId(data);

		String withODSID = "SELECT I.*,O.ODSMEMBERID,O.ODSMEMBERPLANID,WHEN I.COVGENDDT IS NOT NULL "
				+ "THEN 'Y' ELSE 'N' END AS PREGOLIVETERMFLG FROM fullMeminsData AS I LEFT OUTER JOIN"
				+ "    odsIDData AS O ON I.DIPATIENTID = O.DIPATIENTID";

		/**
		 * Add Key Generation logic
		 */
		String query = "SELECT * FROM current_demong AS D INNER JOIN"
				+ "    fullMeminsData AS M ON M.DIPATIENTID = D.DIPATIENTID"
				+ "        AND M.RELATIONSHIPTYPCD = D.RELATIONSHIPTYPCD"
				+ "        AND M.AHMSUPPLIERID = D.AHMSUPPLIERID";
		/**
		 * Return the data frame
		 */
		return null;
	}

	@Override
	public void clean() {
		// TODO Auto-generated method stub

	}

}
