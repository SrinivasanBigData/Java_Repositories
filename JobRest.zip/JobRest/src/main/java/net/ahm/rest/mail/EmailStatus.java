package net.ahm.rest.mail;

import java.io.Serializable;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public class EmailStatus implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String SUCCESS = "SUCCESS";
	public static final String ERROR = "ERROR";

	private final String to, from;
	private String status, errorMessage;

	public EmailStatus success() {
		this.status = SUCCESS;
		return this;
	}

	public EmailStatus error(String errorMessage) {
		this.status = ERROR;
		this.errorMessage = errorMessage;
		return this;
	}

	public boolean isSuccess() {
		return SUCCESS.equals(this.status);
	}

	public boolean isError() {
		return ERROR.equals(this.status);
	}
}
