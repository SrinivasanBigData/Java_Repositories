package net.ahm.rest.config;

import java.io.Serializable;

public class Jobsubmitdata implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1442067420165337804L;

}
