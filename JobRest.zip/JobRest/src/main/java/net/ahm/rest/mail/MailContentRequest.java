package net.ahm.rest.mail;

import lombok.Data;

@Data
public class MailContentRequest {
	
	private String error_type;
	private String message;
	private String team;
	private String control_fileContent;
}
