package net.ahm.rest.mail;

import java.io.Serializable;
import java.util.Map;

import lombok.Data;

@Data
public class MailMessager implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String from;
	private String to;
	private String subject;
	private String content;
	private String emailTemplateName;

	public enum MAILSENDTO {
		ADP, PDS, ANALYST, SUPPORT;
	}

	private Map<String, Object> model;

	private MAILSENDTO sento;
}
