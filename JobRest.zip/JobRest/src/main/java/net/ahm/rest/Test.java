package net.ahm.rest;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.context.IContext;
import org.thymeleaf.messageresolver.StandardMessageResolver;

public class Test {
	public static void main(String[] args) {
		//https://www.suancaiyu.xyz/read/2646.html
		TemplateEngine engine = new TemplateEngine();

		// Message
		StandardMessageResolver resolver = new StandardMessageResolver();
		resolver.addDefaultMessage("oreore.num", "{0}");
		engine.setMessageResolver(resolver);

		// template
		String template = "[[# {oreore.num ($ {a + b})}]]";

		// Parameters
		Map<String, Object> params = new HashMap<>();
		params.put("a", 1000);
		params.put("b", 20000);
		IContext context = new Context(Locale.getDefault(), params);

		// Generate
		String result = engine.process(template, context);
	}

}
