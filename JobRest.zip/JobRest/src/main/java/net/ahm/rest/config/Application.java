package net.ahm.rest.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import lombok.extern.slf4j.Slf4j;
import net.ahm.di.rest.service.EmailSendService;
import net.ahm.rest.mail.MailMessager;

@SpringBootApplication
@Slf4j
public class Application implements ApplicationRunner {

	@Autowired
	private EmailSendService emailService;

	public static void main(String[] args) throws Exception {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(ApplicationArguments applicationArguments) throws Exception {

		log.info("Sending Email with Thymeleaf HTML Template Example");

		MailMessager mail = new MailMessager();
		mail.setFrom("no-reply@memorynotfound.com");
		mail.setTo("info@memorynotfound.com");
		mail.setSubject("Sending Email with Thymeleaf HTML Template Example");

		Map<String, Object> model = new HashMap<>();
		model.put("name", "Memorynotfound.com");
		model.put("location", "Belgium");
		model.put("signature", "https://memorynotfound.com");
		mail.setModel(model);

		emailService.sendSimpleMessage(mail);
	}
}