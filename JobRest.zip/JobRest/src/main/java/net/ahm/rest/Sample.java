package net.ahm.rest;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.thymeleaf.context.Context;
import org.thymeleaf.context.IContext;
import org.thymeleaf.spring4.SpringTemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.StringTemplateResolver;

public class Sample {
	// https://turreta.com/2017/01/11/render-xml-using-thymeleaf/
	// https://stackoverflow.com/questions/28774903/spring-boot-thymeleaf-with-xml-templates
	public static void main(String[] args) {
		final SpringTemplateEngine templateEngine = new SpringTemplateEngine();
		final StringTemplateResolver templateResolver = new StringTemplateResolver();
		templateResolver.setOrder(Integer.valueOf(3));
		templateResolver.setTemplateMode(TemplateMode.XML);
		templateResolver.setCacheable(false);
		templateEngine.addTemplateResolver(templateResolver);

		String template = "<a>JIIII [[${c[0]}]]</a><b th:text=\"${a}\"></b>";

		// Parameters
		Map<String, Object> params = new HashMap<>();
		params.put("a", 1000);
		params.put("b", 20000);
		params.put("c", Arrays.asList(1, 2, 3));
		
		IContext context = new Context(Locale.getDefault(), params);
		String result = templateEngine.process(template, context);
		System.out.println(result);
	}
}
