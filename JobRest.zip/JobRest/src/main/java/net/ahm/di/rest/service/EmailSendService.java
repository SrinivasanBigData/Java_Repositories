package net.ahm.di.rest.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Optional;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring4.SpringTemplateEngine;

import net.ahm.rest.mail.EmailStatus;
import net.ahm.rest.mail.MailMessager;

@Service
public class EmailSendService {

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private SpringTemplateEngine templateEngine;
	private MimeMessageHelper helper;

	public EmailStatus sendSimpleMessage(MailMessager mail) throws MessagingException, IOException {
		try {
			MimeMessage message = mailSender.createMimeMessage();
			if (Optional.ofNullable(mail.getEmailTemplateName()).isPresent()) {
				helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
						StandardCharsets.UTF_8.name());
				helper.setText(getMailHtml(mail.getEmailTemplateName(), mail.getModel()), true);
			} else {
				helper = new MimeMessageHelper(message, StandardCharsets.UTF_8.name());
				helper.setText(mail.getContent(), true);
			}
			helper.setTo(mail.getTo());
			helper.setSubject(mail.getSubject());
			helper.setFrom(mail.getFrom());
			mailSender.send(message);
			return new EmailStatus(mail.getTo(), mail.getFrom()).success();
		} catch (Exception e) {
			return new EmailStatus(mail.getTo(), mail.getFrom()).error(e.getMessage());
		}
	}

	private String getMailHtml(String emailTemplateName, Map<String, Object> model) {
		Context context = new Context();
		context.setVariables(model);
		return templateEngine.process(emailTemplateName, context);
	}

}
