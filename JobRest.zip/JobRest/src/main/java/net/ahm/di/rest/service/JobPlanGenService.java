package net.ahm.di.rest.service;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.context.IContext;
import org.thymeleaf.spring4.SpringTemplateEngine;

import net.ahm.rest.config.Jobsubmitdata;

@Service
public class JobPlanGenService implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Autowired
	@Qualifier("xmltemplateEngine")
	private SpringTemplateEngine xmltemplateEngine;

	public String generateExecutionPlan(Jobsubmitdata jobsubmitdata) {

		String template = "<a th:text=\"${a}\"></a><b th:text=\"${b}\"></b>";
		// Parameters
		Map<String, Object> params = new HashMap<>();
		params.put("a", 1000);
		params.put("b", 20000);
		params.put("c", Arrays.asList(1, 2, 3));
		IContext contexts = new Context(Locale.getDefault(), params);
		String result = xmltemplateEngine.process(template, contexts);

		System.out.println(result);

		return result;
	}

}
